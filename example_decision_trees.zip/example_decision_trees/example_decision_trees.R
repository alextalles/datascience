#####################################################################
################# Machine Learning - Decision Trees #################
#####################################################################

######################################################################
### Problema: Prever se determinado cliente tem limite de cr�dito. ###
######################################################################

### Instalando pacotes necess�rios ...
install.packages("randomForest")
install.packages("tree")
install.packages("readr")

# Carregando os bibliotecas necess�rias ...
library(ISLR)
library(tree)
library(dplyr)
library(randomForest)
library(readr)

# Lendo o Dataset ....
credit = read.csv("UCI_Credit_Card.csv")
View(credit)

# Colocando os labels corretos em vari�veis categ�ricas ...
credit$SEX = factor(credit$SEX, levels = c(1, 2),
                    labels = c("Male", "Female"))

credit$EDUCATION = factor(credit$EDUCATION, levels = c(1, 2, 3, 4, 5, 6),
                          labels = c("Grad School", "University", "High School",
                                     "Others", "Unknown", "Unknown"))

scredit$MARRIAGE = factor(credit$MARRIAGE, levels = c(1, 2, 3),
                         labels = c("Married", "Single", "Other"))

credit$default.payment.next.month = factor(credit$default.payment.next.month,
                                           levels = c(0,1), labels = c("No", "Yes"))

# Verificando a vari�vel resposta ...
table(credit$default.payment.next.month)
prop.table(table(credit$default.payment.next.month))*100

# Verificando a quantidade de missings que tem em cada vari�vel ...
sapply(credit, function(x) sum(is.na(x)))

# Eliminando os missings, pois � um problema ...
credit = na.omit(credit)

### Definindo a semente ...
set.seed(5)

# Dividindo o Dataset em conjunto de treinamento e conjunto de teste ...
# Recuperando todas as linhas do Dataset ...
train = sample(1:nrow(credit),
               nrow(credit) * .7)

names(credit)
View(credit)

# Excluindo o ID por n�o ter relev�ncia para o modelo ...
fit = randomForest(default.payment.next.month ~ .- ID, 
                   data = credit,
                   subset=train,
                   mtry = 5,
                   importance  = TRUE)

fit
importance(fit)
varImpPlot(fit)

# Obtendo as estimativas do modelo ajustado para uma base de dados nova ou n�o ...  
yhattrain = predict(fit, type = "class")
yhattest = predict(fit, newdata = credit[-train, ], type = "class")

# Aplicando a Matriz de Confus�o ...
table(credit$default.payment.next.month[train], yhattrain)
table(credit$default.payment.next.month[-train], yhattest)

# Calculando o Erro de treino ...
auc(credit$default.payment.next.month[train], as.numeric(yhattrain))
# Calculando o Erro de teste ...
auc(credit$default.payment.next.month[-train], as.numeric(yhattest))
