#!/usr/bin/env python
# coding: utf-8

# Classificador para prevê se uma Pessoa pode ganhar menos ou igual a 50k ou mais que 50k de renda por ano.

# In[166]:


import pandas as pd


# In[167]:


ds_census = pd.read_csv('census.csv')
ds_census.head(10)


# In[159]:


# Observa os valores <=50k ou >50.
ds_census['income'].unique()


# In[69]:


# Verifica-se a quantidade de registros no Dataset.
ds_census.shape


# In[90]:


# Armazenar as features previsoras na variável X e transformá-las no Numpy Array.
x = ds_census.iloc[:, 0:14].values
# Armazenar a resposta que é a Classe (Rótulo).
Y = ds_census.iloc[:,14].values


# In[91]:


# Note que apresenta muitos valores categóricos, portanto precisa ser transformados em valores númericos.
print(x)


# In[92]:


# Note que apresenta apenas valores númericos, portanto não precisa ser transformados.
print(y)


# Realizando Pré-Processamento dos Dados ...

# In[93]:


# Transforma os valores categóricos, por exemplo "State-gov", "Bachelors", "Never-married" apresentados abaixo, 
# em valores númericos, para que o modelo consiga compreender e fazer o treinamento.
x[0]


# In[94]:


from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
x[:, 1] = label_encoder.fit_transform(x[:, 1])
x[:, 3] = label_encoder.fit_transform(x[:, 3])
x[:, 5] = label_encoder.fit_transform(x[:, 5])
x[:, 6] = label_encoder.fit_transform(x[:, 6])
x[:, 7] = label_encoder.fit_transform(x[:, 7])
x[:, 8] = label_encoder.fit_transform(x[:, 8])
x[:, 9] = label_encoder.fit_transform(x[:, 9])
x[:, 13] = label_encoder.fit_transform(x[:, 13])


# In[95]:


# Certificar se a transformação foi realizada corretamente.
print(x)


# Aplicando Padronização dos Dados ...

# In[96]:


from sklearn.preprocessing import StandardScaler
stander_x = StandardScaler()
x = stander_x.fit_transform(x)


# In[97]:


print(x)


# Dividindo Dataset em Treinamento e Teste ...

# In[98]:


from sklearn.model_selection import train_test_split
x_treinamento, x_teste, y_treinamento, y_teste = train_test_split(x, y, test_size = 0.3)


# In[99]:


# Visualizar as dimensões.
print(x_treinamento.shape)
print(y_treinamento.shape)


# In[100]:


# Visualizar as dimensões.
print(x_teste.shape)
print(y_teste.shape)


# In[101]:


from sklearn.linear_model import LogisticRegression
# max_iter para ajustar o algoritmo.
classificador = LogisticRegression(max_iter = 10000)
classificador.fit(x_treinamento, y_treinamento)


# In[108]:


previsoes = classificador.predict(x_teste)


# In[109]:


# Respostas das previsões.
print(previsoes)


# In[111]:


print(y_teste)


# In[112]:


# Comparando as respectivas respostas de (x_teste) com as respostas de (y_teste).
# <=50K - >50k : não acertou
# <=50K - <=50K : acertou
# >50K - <=50K : não acertou
# <=50K - <=50K : acertou
# <=50K - <=50K : acertou
# >50K - <=50K : não acertou


# In[113]:


from sklearn.metrics import accuracy_score
taxa_acerto = accuracy_score(y_teste, previsoes)
print(taxa_acerto)

