###########################################################################
############# Machine Learning - Suport Vector Machine (SVM) ##############
###########################################################################

###########################################################################
####### Prev� se o paciente tem exist�ncia de doen�a cardiovascular. ######
###########################################################################

# Instalando os pacotes necess�rios ...
install.packages(c("e1071", "ROC", "pROC", "ISLR", "dplyr", "readr"))

# Carregando os pacotes necess�rios ...
library(e1071) ## Machine Learning
library(ROCR) # Curva ROC e AUC
library(pROC) # Curva ROC e AUC
library(ISLR) # Pacote do livro | Dados
library(dplyr) # Manipula��o de Dados Tidy
library(readr) # Leitura de Bancos de Dados externos

# Definindo a semente ...
set.seed(1)
x = matrix(rnorm(20 * 2), ncol = 2)
x
y = c(rep(-1, 10), rep(1, 10))
y
x[y == 1] = x[y == 1] + 1

plot(x, col = (3 - y))

dat = data.frame(x = x, y = as.factor(y))
dat

### SUport Vector Classifier
fit1 = svm(y ~., data = dat,
          kernel = "linear",
          cost = 0.1,
          scale = F)

fit1
plot(fit1, dat)
fit1$index

# Custo � um Tunning Parameter.
# Usar Cross-Validation para verificar o melhor valor de C.

tune.out <- tune(svm, y ~ ., data = dat,
                kernel = "linear",
                ranges = list(cost = c(0.001, 0.01, 0.1,
                                       1, 5, 10, 100)))

summary(tune.out)

# Lendo o Dataset ...
cardio = read.csv2("Cardio.csv")

View(cardio)
cadio$gender = factor(cardio$gender, levels = c(1, 2),
                      labels = c("Male", "Female"))

cardio$cardio = factor(cardio$cardio, levels = c(0, 1))

table(cardio$cardio)
dim(cardio)

# Dividindo o Dataset em conjunto de treinamento e teste ...
set.seed(5)
train = sample(1: nrow(cardio),
                       nrow(cardio) * 0.7)

fit = svm(cardio ~ . -id, data = cardio[-train, ],
           kernel = "radial", cost = 500, gamma = 1)

summary(fit)

# Obtendo as estimativas do modelo ajustado para uma base de dados nova ou n�o ...  
yhattrain = predict(fit, type = "class")
yhattest = predict(fit, newdata = cardio[-train, ],
                   type = "class")

# Calculando AUC do treinamento ...
auc(cardio$cardio[train], as.numeric(yhattrain))

# Calculando AUC do teste ...
auc(cardio$cardio[-train], as.numeric(yhattest))

               